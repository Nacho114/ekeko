ENTRY = "entry"
EXIT = "exit"
PLOT_COLUMNS = "plot_columns"
